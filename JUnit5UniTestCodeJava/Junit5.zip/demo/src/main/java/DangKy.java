public class DangKy {
    public String register(
            String firstName,
            String lastName,
            String email,
            String passwrord
    ){
    String kq="";
        if( firstName == "" )
        {
            kq ="Please field firstName";
        }else if(lastName == "")
        {
            kq = "Please field lastName";
        }else if(email == "")
        {
            kq = "Please field Email";
        } else if(passwrord == "")
        {
            kq = "Please field passWord";
        } else if (firstName.length()  >= 20) {
            kq = "First name field can't be more than 20 characters";
        } else if (lastName.length() >= 20) {
            kq = "Last name field can't be more than 20 characters";
        } else if (passwrord.length() >= 8) {
            kq = "Password field must be more than 8 characters";
        } else if(firstName.matches("^[a-zA-Z\\s]+$")) {

        } else {
            kq = "first name is not valid";
        } if(lastName.matches("^[a-zA-Z\\s]+$")) {

        } else {
            kq = "last name is not valid";
        } if (firstName == " "){
            kq = "The first character cannot be a space";
        } else if (lastName == " ") {
            kq = "The first character cannot be a space";
        } else if (email == " "){
            kq = "The first character cannot be a space";
        } else if (passwrord == " ") {
            kq = "The first character cannot be a space";
        }
        return kq;


    }


}
