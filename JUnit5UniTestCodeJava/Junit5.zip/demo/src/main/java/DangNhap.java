public class DangNhap {
    public String dangnhap(
            String EMAIL_REGEX,
            String password
    ){
        String kq = "";
        if( EMAIL_REGEX == "^[\\w-_\\.+]*[\\w-_\\.]\\ @([\\w]+\\.)+[\\w]+[\\w]$" ){

        } else {
            kq = "Email invalid";
        }
        return kq;
    }


}
