import org.junit.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class TestDangky {
    DangKy dk = new DangKy();

    @Test
    public void dangky1(){
        assertEquals("Please field firstName", dk.register("", "Thang",
                "hf@gmail.com", "123"));
    }
    @Test
    public void dangky2(){
        assertEquals("Please field lastName", dk.register("Nguyen", "",
                "hf@gmail.com", "123"));
    }
    @Test
    public void dangky3(){
        assertEquals("Please field Email", dk.register("Nguyen", "Thang",
                "", "123"));
    }
    @Test
    public void dangky4(){
        assertEquals("Please field passWord", dk.register("Nguyen", "Thang",
                "ha1232gmail.com", ""));
    }
    @Test
    public void dangky5() {
        assertEquals("First name field can't be more than 20 characters", dk.register("Nguhfgfhfhfhfhfhfhfyen", "Thang",
                "ha1232gmail.com", "123"));
    }
    @Test
    public void dangky6() {
        assertEquals("Last name field can't be more than 20 characters", dk.register("Nguyen", "Thafshfhdfdhgjshfdhg",
                "ha1232gmail.com", "123"));
    }
    @Test
    public void dangky7() {
        assertEquals("Password field must be more than 8 characters", dk.register("Nguyen", "Thang",
                "ha1232gmail.com", "11223323"));
    }
    @Test
    public void dangky8() {
        assertEquals("first name is not valid", dk.register("1Nguyen", "Thang",
                "ha1232gmail.com", "112"));
    }
    @Test
    public void dangky9() {
        assertEquals("last name is not valid", dk.register("Nguyen", "1",
                "ha1232gmail.com", "112"));
    }
    @Test
    public void dangky10() {
        assertEquals("The first character cannot be a space", dk.register(" ", "Thang",
                "ha1232gmail.com", "112"));
    }
    @Test
    public void dangky11() {
        assertEquals("The first character cannot be a space", dk.register("Nguyen", " ",
                "ha1232gmail.com", "112"));
    }
    @Test

    public void dangky13() {
        assertEquals("The first character cannot be a space", dk.register("Nguyen", "Thang",
                "ha123@gmail.com", " "));
    }

}
