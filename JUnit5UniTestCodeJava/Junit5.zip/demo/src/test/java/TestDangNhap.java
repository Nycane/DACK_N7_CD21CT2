import org.junit.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class TestDangNhap {
    DangNhap dn = new DangNhap();
    @Test
    public void dangnhap1(){
        assertEquals("Email invalid", dn.dangnhap("than^g@gmail.com","123"));
    }

}
