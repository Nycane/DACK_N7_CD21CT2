package test;


import driver.driverFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import java.time.Duration;

@Test
public class TESTCASE04 {

    public static void compareProduct() {

        WebDriver driver = driverFactory.getChromeDriver();
        try {
            //step 1:
            driver.get("https://adamstorevn.com/");
            //step 2:
            WebElement product = driver.findElement(By.cssSelector("body > header:nth-child(3) > nav:nth-child(2) > div:nth-child(1) > div:nth-child(1) > ul:nth-child(2) > li:nth-child(2) > a:nth-child(1)"));
            product.click();

            //step 3:
            //product 1
            WebElement detailProduct1 = driver.findElement(By.cssSelector("div[class='grid-uniform product-list mg-left-0'] div:nth-child(1) div:nth-child(1) div:nth-child(2) a:nth-child(1)"));
            detailProduct1.click();

            WebElement addProductCart1 = driver.findElement(By.cssSelector("button[id='AddToCart'] span"));
            addProductCart1.click();

            Thread.sleep(2000);
            WebElement checkOut = driver.findElement(By.cssSelector("a[class='modalAddComplete-close']"));
            checkOut.click();

            //back page shopping
            Thread.sleep(2000);
            WebElement backProduct = driver.findElement(By.cssSelector("body > header:nth-child(5) > nav:nth-child(2) > div:nth-child(1) > div:nth-child(1) > ul:nth-child(2) > li:nth-child(2) > a:nth-child(1)"));
            backProduct.click();
            //product 2
            WebElement detailProduct2 = driver.findElement(By.cssSelector("div[class='colection-content grid mg-left-0'] div:nth-child(2) div:nth-child(1) div:nth-child(2) a:nth-child(1)"));
            detailProduct2.click();


            String windowCurrent = driver.getWindowHandle();
            WebElement addProductCart2 = driver.findElement(By.cssSelector("#AddToCart"));
            addProductCart2.click();

            //step 4:

            for (String window : driver.getWindowHandles()){
                if(!window.equals(windowCurrent)){
                    driver.switchTo().window(window);
                }
            }
            WebElement titleCompate = driver.findElement(By.xpath("//*[@id=\"modalAddComplete\"]/div/div/div/h2"));
            if(titleCompate.isDisplayed()){
                System.out.println("Có hiển thị Popup");
            }else{
                System.out.println("Không hiển thị popup");
            }
            WebElement titleproduct1=driver.findElement(By.xpath("//*[@id=\"modalAddComplete\"]/div/div/form/div/div[1]/table/tbody/tr[1]"));
            if(titleproduct1.isDisplayed()){
                System.out.println("ÁO VEST BEIGE HỌA TIẾT HERRINGBONE có trong popup");
            }else{
                System.out.println("ÁO VEST BEIGE HỌA TIẾT HERRINGBONE không có trong popup");
            }
            WebElement titleProduct2=driver.findElement(By.xpath("//*[@id=\"modalAddComplete\"]/div/div/form/div/div[1]/table/tbody/tr[2]"));
            if(titleProduct2.isDisplayed()){
                System.out.println("ÁO VEST ADAM NÂU 2 HÀNG KHUY HỌA có trong popup");
            }else{
                System.out.println("ÁO VEST ADAM NÂU 2 HÀNG KHUY HỌA không có trong popup");
            }

            //driver.switchTo().window(windowCurrent);

            Thread.sleep(4000);
        } catch (Exception e) {
            e.printStackTrace();
        }

        //7. Quit browser session
        driver.quit();
    }
}
