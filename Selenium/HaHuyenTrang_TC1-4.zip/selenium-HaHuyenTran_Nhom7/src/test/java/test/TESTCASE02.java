package test;


import driver.driverFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.Test;


@Test
public class TESTCASE02 {

    public static void ComparePrice() {

        WebDriver driver = driverFactory.getChromeDriver();
        try {
            //step 1:
            driver.get("https://adamstorevn.com/");
            //step 2:
            WebElement product = driver.findElement(By.cssSelector("body > header:nth-child(3) > nav:nth-child(2) > div:nth-child(1) > div:nth-child(1) > ul:nth-child(2) > li:nth-child(2) > a:nth-child(1)"));
            product.click();
            //step 3:
            WebElement priceProduct = driver.findElement((By.cssSelector("#collection-wrapper > div > div > div.colection-content.grid.mg-left-0 > div.collection-list.collection-body.grid__item.large--one-whole.pd-left-0 > div.grid-uniform.product-list.mg-left-0 > div:nth-child(4) > div > div.product-info.text-center > span > span")));
            String priceVl = priceProduct.getText();
            System.out.println(priceVl);

//        step 4:
            WebElement clickProduct = driver.findElement(By.cssSelector("#collection-wrapper > div > div > div.colection-content.grid.mg-left-0 > div.collection-list.collection-body.grid__item.large--one-whole.pd-left-0 > div.grid-uniform.product-list.mg-left-0 > div:nth-child(4) > div > div.product-info.text-center > a"));
            clickProduct.click();
//        step 5:
            WebElement detailPrice = driver.findElement((By.cssSelector("#ProductPrice")));
            String detailPriceVl = detailPrice.getText();
            System.out.println(detailPriceVl);

            if(priceVl.equals(detailPriceVl)){
                System.out.println("Giá của 2 trang bằng nhau");
            }else{
                System.out.println("Giá của 2 trang không bằng nhau");
            }


            Thread.sleep(2000);
        }catch (Exception e){
            e.printStackTrace();
        }
        //7. Quit browser session
        driver.quit();
    }
}
