package test;


import driver.driverFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.Test;


@Test
public class TESTCASE01 {

    public static void checkWeb() {

        WebDriver driver = driverFactory.getChromeDriver();
        try {
            //step 1:
            driver.get("https://adamstorevn.com/");
            //step 2:
            WebElement sanPham = driver.findElement(By.cssSelector("body > header:nth-child(3) > nav:nth-child(2) > div:nth-child(1) > div:nth-child(1) > ul:nth-child(2) > li:nth-child(2) > a:nth-child(1)"));
            sanPham.click();
            //step 3:
            WebElement verifyTitle=driver.findElement(By.cssSelector("#breadcrumb-wrapper > div.breadcrumb-small.text-left > span:nth-child(3)"));
            Assert.assertEquals(verifyTitle.getText(),"BỘ SƯU TẬP SUIT ADAM 2023");
            System.out.println(verifyTitle.getText());


            //step 4:
            WebElement dropdownElement = driver.findElement(By.cssSelector("#SortBy"));
            Select selectOption = new Select(dropdownElement);
            selectOption.selectByVisibleText("Mới nhất");

            Thread.sleep(2000);
        }catch (Exception e){
            e.printStackTrace();
        }
        //7. Quit browser session
        driver.quit();
    }
}
