package test;

import driver.driverFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.time.Duration;

public class TESTCASE03 {
    @Test
    public static void testCartEmpty() {

        WebDriver driver = driverFactory.getChromeDriver();

        try {
            //step 1:
            driver.get("https://adamstorevn.com/");
            //step 2:
            WebElement product = driver.findElement(By.cssSelector("body > header:nth-child(3) > nav:nth-child(2) > div:nth-child(1) > div:nth-child(1) > ul:nth-child(2) > li:nth-child(2) > a:nth-child(1)"));
            product.click();

            WebElement viewDetail = driver.findElement(By.cssSelector("div[class='grid-uniform product-list mg-left-0'] div:nth-child(1) div:nth-child(1) div:nth-child(2) a:nth-child(1)"));
            viewDetail.click();

            //step 3:
            WebElement addToCart = driver.findElement(By.cssSelector("button[id='AddToCart'] span"));
            addToCart.click();

            WebElement updateQualtity = driver.findElement(By.cssSelector("#updates_"));
            updateQualtity.clear();
            updateQualtity.sendKeys("1000000");

            WebElement updateCart = driver.findElement(By.cssSelector("button[name='update']"));
            updateCart.click();

            //step 4:
            Thread.sleep(2000);
            WebElement messageCart = driver.findElement((By.cssSelector("#modalAddComplete > div > div > form > div > div > p:nth-child(1)")));
            System.out.println(messageCart.getText());
            Assert.assertNotNull(messageCart.getText());


        Thread.sleep(4000);
        } catch (Exception e) {
            e.printStackTrace();
        }

        //7. Quit browser session
        driver.quit();
    }
}
