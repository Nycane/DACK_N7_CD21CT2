package test;

import driver.driverFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.time.Duration;

@Test
public class TESTCASE06 {
    public static void signIn() {

        WebDriver driver = driverFactory.getChromeDriver();
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
        try {
            //step 1:
            driver.get("https://adamstorevn.com/");
            //step 2:
            WebElement clickAccount = driver.findElement(By.cssSelector("body > header:nth-child(3) > nav:nth-child(2) > div:nth-child(1) > div:nth-child(1) > ul:nth-child(3) > li:nth-child(3) > a:nth-child(1) > i:nth-child(1)"));
            clickAccount.click();

            //step 3:
            Thread.sleep(2000);
            WebElement email = driver.findElement(By.cssSelector("#CustomerEmail"));
            email.sendKeys("taolaobidao111123@gmail.com");
            WebElement password = driver.findElement(By.cssSelector("#CustomerPassword"));
            password.sendKeys("123123");

            WebElement buttonSingIn = driver.findElement(By.cssSelector("input[value='Đăng nhập']"));
            buttonSingIn.click();

            //step 4:
            WebElement product = driver.findElement(By.cssSelector("body > header:nth-child(3) > nav:nth-child(2) > div:nth-child(1) > div:nth-child(1) > ul:nth-child(2) > li:nth-child(2) > a:nth-child(1)"));
            product.click();

            WebElement detailProduct = driver.findElement(By.cssSelector("div[class='grid-uniform product-list mg-left-0'] div:nth-child(1) div:nth-child(1) div:nth-child(2) a:nth-child(1)"));
            detailProduct.click();

            WebElement addProductCart = driver.findElement(By.cssSelector("#AddToCart"));
            addProductCart.click();

            //step 5:
            WebElement payment = driver.findElement(By.cssSelector(".btnProceedCheckout"));
            payment.click();

            //step 6:
            Thread.sleep(2000);
            WebElement delivery = driver.findElement(By.cssSelector("#customer_pick_at_location_false"));
            delivery.click();

            Thread.sleep(2000);
            WebElement phoneNumber = driver.findElement(By.cssSelector("#billing_address_phone"));
            phoneNumber.sendKeys("0909009009");

            Thread.sleep(2000);
            WebElement myAddress = driver.findElement(By.xpath("//input[@id='billing_address_address1']"));
            myAddress.sendKeys("12 TDT");



            Thread.sleep(2000);
            WebElement dropdownProvince = driver.findElement(By.cssSelector("#customer_shipping_province"));
            Select selectOption = new Select(dropdownProvince);
            selectOption.selectByVisibleText("Hồ Chí Minh");

            Thread.sleep(2000);
            WebElement dropdownDistrict = driver.findElement(By.cssSelector("#customer_shipping_district"));
            Select selectOption1 = new Select(dropdownDistrict);
            selectOption1.selectByVisibleText("Quận Tân Phú");

            Thread.sleep(2000);
            WebElement dropdownWard = driver.findElement(By.cssSelector("#customer_shipping_ward"));
            Select selectOption2 = new Select(dropdownWard);
            selectOption2.selectByVisibleText("Phường Hòa Thạnh");





            Thread.sleep(4000);
        } catch (Exception e) {
            e.printStackTrace();
        }

        //7. Quit browser session
        driver.quit();
    }
}
