package test;


import driver.driverFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.time.Duration;

@Test
public class TESTCASE08 {


    public static void changeQualtity() {

        WebDriver driver = driverFactory.getChromeDriver();
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
        try {
            //step 1:
            driver.get("https://adamstorevn.com/");
            //step 2:
            WebElement clickAccount = driver.findElement(By.cssSelector("body > header:nth-child(3) > nav:nth-child(2) > div:nth-child(1) > div:nth-child(1) > ul:nth-child(3) > li:nth-child(3) > a:nth-child(1) > i:nth-child(1)"));
            clickAccount.click();

            //step 3:
            Thread.sleep(2000);
            WebElement email = driver.findElement(By.cssSelector("#CustomerEmail"));
            email.sendKeys("taolaobidao123@gmail.com");
            WebElement password = driver.findElement(By.cssSelector("#CustomerPassword"));
            password.sendKeys("123123");

            WebElement buttonSingIn = driver.findElement(By.cssSelector("input[value='Đăng nhập']"));
            buttonSingIn.click();

            //step 4:
            WebElement product = driver.findElement(By.cssSelector("body > header:nth-child(3) > nav:nth-child(2) > div:nth-child(1) > div:nth-child(1) > ul:nth-child(2) > li:nth-child(2) > a:nth-child(1)"));
            product.click();

            WebElement detailProduct = driver.findElement(By.cssSelector("div[class='grid-uniform product-list mg-left-0'] div:nth-child(1) div:nth-child(1) div:nth-child(2) a:nth-child(1)"));
            detailProduct.click();

            WebElement addCartProduct = driver.findElement(By.cssSelector("button[id='AddToCart'] span"));
            addCartProduct.click();

            WebElement qualtity = driver.findElement(By.cssSelector("#updates_"));
            qualtity.clear();
            qualtity.sendKeys("10");

            WebElement updateCart = driver.findElement(By.cssSelector("button[name='update']"));
            updateCart.click();
            //step 5:
            Thread.sleep(4000);
            WebElement total = driver.findElement(By.cssSelector("#modalAddComplete > div > div > form > div > div.modal-tbl-cart.medium--hide.small--hide > table > tbody > tr > td.product-money"));
            Assert.assertEquals(total.getText(), "29,500,000₫");
            System.out.println(total.getText());

            Thread.sleep(4000);
        } catch (Exception e) {
            e.printStackTrace();
        }

        //7. Quit browser session
        driver.quit();
    }
}
