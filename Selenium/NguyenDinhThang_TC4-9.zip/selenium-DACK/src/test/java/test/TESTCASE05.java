package test;


import driver.driverFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.time.Duration;

@Test
public class TESTCASE05 {

    public static void signUp() {

        WebDriver driver = driverFactory.getChromeDriver();
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
        try {
            //step 1:
            driver.get("https://adamstorevn.com/");
            //step 2:
            WebElement clickAccount = driver.findElement(By.cssSelector("body > header:nth-child(3) > nav:nth-child(2) > div:nth-child(1) > div:nth-child(1) > ul:nth-child(3) > li:nth-child(3) > a:nth-child(1) > i:nth-child(1)"));
            clickAccount.click();

            //step 3:
            WebElement clickSignUp = driver.findElement(By.cssSelector("body > div:nth-child(5) > main:nth-child(1) > section:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > form:nth-child(1) > p:nth-child(12) > a:nth-child(1)"));
            clickSignUp.click();

            //step 4:
            Thread.sleep(4000);
            WebElement firstName = driver.findElement(By.cssSelector("#FirstName"));
            firstName.sendKeys("A");
            WebElement lastName = driver.findElement(By.cssSelector("#LastName"));
            lastName.sendKeys("Nguyen Van");
            WebElement email = driver.findElement(By.cssSelector("body > div:nth-child(5) > main:nth-child(1) > section:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > form:nth-child(1) > input:nth-child(8)"));
            email.sendKeys("taolaobidao111123@gmail.com");
            WebElement password = driver.findElement(By.cssSelector("#CreatePassword"));
            password.sendKeys("123123");

            //step 5:
            WebElement buttonSignUp = driver.findElement(By.cssSelector("input[value='Đăng ký']"));
            buttonSignUp.click();

            //step 6:
            WebElement verifySignUp = driver.findElement(By.cssSelector("#page-wrapper > div > div > div.grid__item.one-third.medium-down--one-whole > h3"));
            Assert.assertEquals(verifySignUp.getText(), "Nguyen Van A");

            //step 7:
            WebElement product = driver.findElement(By.cssSelector("body > header:nth-child(3) > nav:nth-child(2) > div:nth-child(1) > div:nth-child(1) > ul:nth-child(2) > li:nth-child(2) > a:nth-child(1)"));
            product.click();

            WebElement viewDetail = driver.findElement(By.cssSelector("div[class='grid-uniform product-list mg-left-0'] div:nth-child(1) div:nth-child(1) div:nth-child(2) a:nth-child(1)"));
            viewDetail.click();

            //step 8:
            WebElement addToCart = driver.findElement(By.cssSelector("button[id='AddToCart'] span"));
            addToCart.click();

            WebElement note = driver.findElement(By.cssSelector("#CartSpecialInstructions"));
            note.sendKeys("hello");

            WebElement updateCart = driver.findElement(By.cssSelector("button[name='update']"));
            updateCart.click();


            Thread.sleep(4000);
        } catch (Exception e) {
            e.printStackTrace();
        }

        //7. Quit browser session
        driver.quit();
    }
}
