package test;


import driver.driverFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.time.Duration;

@Test
public class TESTCASE07 {

    public static void verifyOrder() {

        WebDriver driver = driverFactory.getChromeDriver();
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
        try {
            //step 1:
            driver.get("https://adamstorevn.com/");
            //step 2:
            WebElement clickAccount = driver.findElement(By.cssSelector("body > header:nth-child(3) > nav:nth-child(2) > div:nth-child(1) > div:nth-child(1) > ul:nth-child(3) > li:nth-child(3) > a:nth-child(1) > i:nth-child(1)"));
            clickAccount.click();

            //step 3:
            Thread.sleep(2000);
            WebElement email = driver.findElement(By.cssSelector("#CustomerEmail"));
            email.sendKeys("taolaobidao123@gmail.com");
            WebElement password = driver.findElement(By.cssSelector("#CustomerPassword"));
            password.sendKeys("123123");

            WebElement buttonSingIn = driver.findElement(By.cssSelector("input[value='Đăng nhập']"));
            buttonSingIn.click();

            //step 4:
            wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.cssSelector("#page-wrapper > div > div > div.grid__item.one-third.medium-down--one-whole > h3"))));
            String status = driver.findElement(By.cssSelector("#page-wrapper > div > div > div.grid__item.one-third.medium-down--one-whole > h3")).getText();
            System.out.println(status);

            Thread.sleep(4000);
        } catch (Exception e) {
            e.printStackTrace();
        }

        //7. Quit browser session
        driver.quit();
    }
}
